#include <valarray>

using namespace std;

int main()
{
}

